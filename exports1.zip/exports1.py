exports.handler = (event, context, callback) => {
    // Succeed with the string "Hello world! one"
    callback(null, 'Hello world!');
}